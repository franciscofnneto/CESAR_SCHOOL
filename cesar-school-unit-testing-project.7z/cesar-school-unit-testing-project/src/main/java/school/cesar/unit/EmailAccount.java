package school.cesar.unit;

import java.util.Date;

public class EmailAccount {

    public String user;
    public String domain;
    public String password;
    public Date lastPasswordUpdate;

    public static void verifyPasswordExpiration(){

        boolean VerificaSenha;
        VerificaSenha verificaSenha = new VerificaSenha();

    }

}
