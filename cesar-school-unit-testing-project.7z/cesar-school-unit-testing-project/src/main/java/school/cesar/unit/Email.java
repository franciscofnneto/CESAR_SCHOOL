package school.cesar.unit;

import java.util.Collection;
import java.util.Date;

public class Email {

        public Date creationDate;
        public String from;
        public Collection<String> to;
        public Collection<String> cc;
        public Collection<String> bcc;
        public String subject;
        public String message;


}
